'use strict';


Array.prototype.contains = function(element){
    return this.indexOf(element) > -1;
};

var profile = require('./data/profiles.js')();
var airline = require('./data/airlines.js')();
var trip = require('./data/trip.js')();
var travelers = []
function getTravlersFightInfo() {
for (var i=0; i<profile.length; i++ )
{	
	var flight = []
	for(var j=0; j<trip.flights.length; j++)
	{
		if(trip.flights[j].travelerIds.contains(profile[i].personId))
		{
			var leg = []
			for(var k=0;k<trip.flights[j].legs.length;k++)
			{
				for(var l=0;l<airline.length; l++)
				{
					var airlineName ='';
					var airlineCode = '';
					var flightNumber ='';
					var frequentFlyerNumber='';
					if(airline[l].code === trip.flights[j].legs[k].airlineCode)
					{
						airlineName = airline[l].name
						airlineCode = airline[l].code
						if(profile[i].rewardPrograms.air[airlineCode] != undefined)
							frequentFlyerNumber=profile[i].rewardPrograms.air[airlineCode]
						else
							frequentFlyerNumber=''
						leg.push({airlineCode:airlineCode,airlineName:airlineName,flightNumber:trip.flights[j].legs[k].flightNumber,frequentFlyerNumber:frequentFlyerNumber})
					}
					
				}
			}
				
				flight.push({legs:leg});
		}
	}
	
	
	travelers.push({id:profile[i].personId,name:profile[i].name,flights:JSON.stringify(flight)}) 
}


  return {
    travelers: travelers
	};
}
module.exports = getTravlersFightInfo;
var features = getTravlersFightInfo();
console.log(features)
